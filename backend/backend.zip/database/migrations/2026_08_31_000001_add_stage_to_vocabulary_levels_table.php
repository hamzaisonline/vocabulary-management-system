<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('vocabulary_levels', function (Blueprint $table) {
            $table->string('stage', 100)->nullable()->after('difficulty');
        });
    }

    public function down(): void
    {
        Schema::table('vocabulary_levels', function (Blueprint $table) {
            $table->dropColumn('stage');
        });
    }
};
